-- SEYRA cloud-only data store (Supabase SQL Editor)
-- Each authenticated user can read/write only their own JSONB app record.
create table if not exists public.seyra_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"theme":"dark","soundEnabled":true,"dailyTasks":[],"weeklyTasks":[],"history":{},"notifSettings":{"enabled":false,"frequency":2,"times":["09:00","20:00"]}}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.seyra_user_data enable row level security;
drop policy if exists "Users can read own SEYRA data" on public.seyra_user_data;
create policy "Users can read own SEYRA data" on public.seyra_user_data for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own SEYRA data" on public.seyra_user_data;
create policy "Users can insert own SEYRA data" on public.seyra_user_data for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own SEYRA data" on public.seyra_user_data;
create policy "Users can update own SEYRA data" on public.seyra_user_data for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update on public.seyra_user_data to authenticated;
