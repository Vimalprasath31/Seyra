# SEYRA Android

A Java + Android WebView application using the supplied SEYRA HTML interface, with an initial SQLite schema.

## Project configuration

- Package: `com.vimal.seyra`
- Minimum Android: 8.0 (API 26)
- Compile / target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- UI: HTML, CSS and JavaScript inside Android WebView
- Database: SQLite starter schema

## Build an APK with GitHub Actions (ZIP upload workflow)

This ZIP is configured to work like the previous Budget Buddy GitHub build process.

1. Create a new GitHub repository.
2. Upload **`SEYRA_Android_Project.zip` unchanged** to the repository root. Keep this exact filename.
3. Commit the upload to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build SEYRA Android APK** and wait for the workflow to finish. It automatically extracts the ZIP and builds the Android project.
6. Open the successful workflow run. Under **Artifacts**, download `SEYRA-Android-debug-APK`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
8. Transfer `app-debug.apk` to your Android phone and install it. If Android asks, allow installation from that source.

The workflow also supports committing the extracted project files directly to the repository root instead of uploading the project ZIP.

You can run the workflow manually from **Actions → Build SEYRA Android APK → Run workflow**.

The workflow uses Java 17, Android SDK, Gradle 8.9 and `assembleDebug`. The generated APK is uploaded as a downloadable GitHub Actions artifact for 30 days.

## Build locally in Android Studio

1. Extract this project ZIP.
2. Open the `SEYRA_Android` folder in Android Studio.
3. Install Android SDK Platform 35 if prompted.
4. Use JDK 17 and wait for Gradle sync.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Current implementation status

### Included now
- Android Studio project scaffold.
- Java `MainActivity` hosting the provided HTML in WebView.
- Original `index.html` in `app/src/main/assets/`.
- SQLite database helper with starter tables for tasks, task completions, daily history and app settings.
- GitHub Actions workflow that extracts this project ZIP when uploaded unchanged, builds the app and publishes a downloadable debug APK artifact.

### Still planned
- The HTML currently reads and writes `seyra_data` through WebView `localStorage`.
- The SQLite tables are initialized but are **not yet connected to the HTML**. The JavaScript-to-Java bridge and migration of task CRUD/history to SQLite are Phase 3.
- Native Android scheduled reminders and notification permission handling are a later phase.
- The HTML currently loads Tailwind, Lucide, canvas-confetti and Google Fonts from external CDNs. Internet permission is included for those resources; bundling them locally for full offline UI rendering is a later improvement.
