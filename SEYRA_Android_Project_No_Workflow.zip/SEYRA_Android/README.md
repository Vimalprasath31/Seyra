# SEYRA — Cloud-connected Android project

This project packages the SEYRA routine tracker as an Android WebView app. Routine data, task completions, history, theme preference, sound preference, and reminder preferences are stored in the user's private Supabase row. Task data is not stored in SQLite or browser localStorage. A network connection is required to load and save account data.

## Project configuration

- Android application ID: `com.vimal.seyra`
- Minimum Android version: 8.0 (API 26)
- Compile / target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- UI: supplied HTML/CSS/JavaScript hosted in Android WebView
- Cloud: Supabase Auth + PostgreSQL with Row Level Security

## Before building

1. In your Supabase project, open **SQL Editor**.
2. Run the `supabase_setup.sql` file included in this project. It creates `public.seyra_user_data` and policies that restrict each signed-in user to their own row.
3. In Supabase **Table Editor**, confirm that the table is named exactly `seyra_user_data`.
4. Confirm the Supabase project URL and publishable key in `app/src/main/assets/index.html` belong to your project. The publishable key is intended for client apps; never put a service-role/secret key in the APK.
5. Enable Email/Password authentication in Supabase. If email confirmation is enabled, confirm the signup email before signing in.

**Important:** The app reads and writes `public.seyra_user_data` (one JSONB row per authenticated user). A table named `seyra_tasks` is not a substitute. If you previously created only `seyra_tasks`, run the included SQL as well; it creates the additional table the app expects and does not delete your existing table.

## Build with GitHub Actions

The project ZIP intentionally does not contain a workflow YAML file. Keep the GitHub Actions workflow as a separate file, as requested. Create `.github/workflows/android.yml` in the GitHub repository using the separate workflow instructions/code supplied for this project.

The workflow must:

- extract this ZIP into the runner workspace;
- change directory into `SEYRA_Android`;
- use JDK 17 and Android SDK Platform 35;
- run `gradle assembleDebug` (or generate/use a Gradle wrapper);
- upload `SEYRA_Android/app/build/outputs/apk/debug/app-debug.apk` as an artifact.

Do not upload this project ZIP and expect GitHub to execute a workflow stored only inside the ZIP. GitHub Actions only discovers workflow files committed under `.github/workflows/` in the repository.

## Build locally in Android Studio

1. Extract the ZIP.
2. Open the `SEYRA_Android` folder in Android Studio.
3. Install Android SDK Platform 35 if prompted and select JDK 17.
4. Sync Gradle, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Included functionality

- Email/password sign-up, sign-in, and sign-out using Supabase Auth.
- Per-user cloud data access protected by Row Level Security.
- Daily task completion recorded by the phone's local calendar date (`YYYY-MM-DD`), preserving previous dates.
- Monthly calendar defaults to the current month and lets the user select a date to inspect its tasks, completion percentage, and streak.
- Yearly progress summary.
- Compact mobile UI and top spacing for the Android status bar.
- Native Android reminder notifications, subject to Android notification permission and alarm scheduling behavior.

## Cloud-only behavior and limitations

- Task and routine data are not cached for offline use. An internet connection is required.
- Supabase Auth persists the login session on the device; this is authentication state, not a local task database.
- The UI loads Tailwind, Supabase JS, Lucide, confetti, and Google Fonts from CDNs, so first launch and some visual assets require internet access.
- Reminder alarms are managed by Android. Exact delivery time can vary with Android battery optimization and OS scheduling.

## Security

The Android app contains only the Supabase project URL and publishable key. Database access must remain protected by the included Row Level Security policies. Never add a service-role key or database password to this project.
