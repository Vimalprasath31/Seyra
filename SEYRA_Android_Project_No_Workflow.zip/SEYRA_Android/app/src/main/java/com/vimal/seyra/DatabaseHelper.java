package com.vimal.seyra;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Initial SEYRA database schema.
 * CRUD methods and the JavaScript bridge will be added in Phase 3.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "seyra.db";
    public static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE tasks (" +
            "id TEXT PRIMARY KEY, " +
            "title TEXT NOT NULL, " +
            "task_type TEXT NOT NULL CHECK(task_type IN ('daily','weekly')), " +
            "created_at INTEGER NOT NULL, " +
            "is_active INTEGER NOT NULL DEFAULT 1)"
        );

        db.execSQL(
            "CREATE TABLE task_completions (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "task_id TEXT NOT NULL, " +
            "completion_date TEXT NOT NULL, " +
            "completed INTEGER NOT NULL DEFAULT 0, " +
            "UNIQUE(task_id, completion_date), " +
            "FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE)"
        );

        db.execSQL(
            "CREATE TABLE daily_history (" +
            "history_date TEXT PRIMARY KEY, " +
            "percentage INTEGER NOT NULL DEFAULT 0, " +
            "completed_count INTEGER NOT NULL DEFAULT 0, " +
            "total_count INTEGER NOT NULL DEFAULT 0)"
        );

        db.execSQL(
            "CREATE TABLE app_settings (" +
            "setting_key TEXT PRIMARY KEY, " +
            "setting_value TEXT NOT NULL)"
        );

        db.execSQL("PRAGMA foreign_keys=ON");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Use explicit, versioned migrations here when the schema changes.
    }
}
