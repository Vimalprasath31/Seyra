package com.vimal.seyra;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 501;
    private WebView webView;
    private String pendingReminderTimes = "[]";
    private boolean pendingReminderEnabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "seyra_daily_reminders",
                "SEYRA Daily Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Daily reminders for your SEYRA routine");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void setRemindersEnabled(boolean enabled, String timesJson) {
            runOnUiThread(() -> {
                pendingReminderEnabled = enabled;
                pendingReminderTimes = timesJson == null ? "[]" : timesJson;
                if (!enabled) {
                    cancelAllReminders();
                    Toast.makeText(MainActivity.this, "SEYRA reminders turned off", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST
                    );
                    return;
                }
                scheduleReminders(pendingReminderTimes);
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && pendingReminderEnabled) {
                scheduleReminders(pendingReminderTimes);
            } else {
                pendingReminderEnabled = false;
                if (webView != null) {
                    webView.evaluateJavascript(
                        "if(window.onNativeNotificationPermissionDenied){window.onNativeNotificationPermissionDenied();}",
                        null
                    );
                }
                Toast.makeText(this, "Allow notifications to receive SEYRA reminders", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void scheduleReminders(String timesJson) {
        try {
            JSONArray times = new JSONArray(timesJson);
            cancelAllReminders();
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            for (int i = 0; i < times.length(); i++) {
                String time = times.optString(i, "");
                if (!time.matches("\\d{2}:\\d{2}")) continue;
                String[] parts = time.split(":");
                int hour = Integer.parseInt(parts[0]);
                int minute = Integer.parseInt(parts[1]);
                if (hour > 23 || minute > 59) continue;

                Calendar next = Calendar.getInstance();
                next.set(Calendar.HOUR_OF_DAY, hour);
                next.set(Calendar.MINUTE, minute);
                next.set(Calendar.SECOND, 0);
                next.set(Calendar.MILLISECOND, 0);
                if (next.getTimeInMillis() <= System.currentTimeMillis()) {
                    next.add(Calendar.DAY_OF_YEAR, 1);
                }

                Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                intent.setAction("com.vimal.seyra.REMINDER_" + i);
                intent.putExtra("reminder_id", i);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    MainActivity.this, i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent
                    );
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent);
                }
                // Receiver schedules the next day's occurrence after delivering the reminder.
            }
            Toast.makeText(this, "SEYRA daily reminders scheduled", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not schedule reminders: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void cancelAllReminders() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < 10; i++) {
            Intent intent = new Intent(this, ReminderReceiver.class);
            intent.setAction("com.vimal.seyra.REMINDER_" + i);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, i, intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
