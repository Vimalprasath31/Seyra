package com.vimal.seyra;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("reminder_id", 0);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(context, "seyra_daily_reminders")
            : new Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("SEYRA Daily Reminder")
            .setContentText("Time to check your tasks and keep your streak alive!")
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_DEFAULT);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(1000 + id, builder.build());

        // Schedule this reminder again for the same local time tomorrow.
        Intent nextIntent = new Intent(context, ReminderReceiver.class);
        nextIntent.setAction(intent.getAction());
        nextIntent.putExtra("reminder_id", id);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            context, id, nextIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar next = Calendar.getInstance();
        next.add(Calendar.DAY_OF_YEAR, 1);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent);
        }
    }
}
